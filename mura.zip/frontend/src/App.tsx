import { Routes, Route, Link } from 'react-router-dom'
import Home from './pages/Home'
import TestPage from './pages/TestPage'
import Results from './pages/Results'
import Dashboard from './pages/Dashboard'
import Analytics from './pages/Analytics'

export default function App() {
  return (
    <div className="min-h-screen bg-slate-50">
      <nav className="bg-white border-b border-slate-200 px-6 py-3">
        <div className="max-w-5xl mx-auto flex items-center justify-between">
          <Link to="/" className="text-xl font-bold text-indigo-600">
            AI-Наставник
          </Link>
          <div className="flex gap-4 text-sm">
            <Link to="/" className="text-slate-600 hover:text-indigo-600">Главная</Link>
            <Link to="/dashboard" className="text-slate-600 hover:text-indigo-600">Кабинет</Link>
            <Link to="/analytics" className="text-slate-600 hover:text-indigo-600">Аналитика</Link>
          </div>
        </div>
      </nav>
      <main className="max-w-5xl mx-auto px-6 py-8">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/test/:testId" element={<TestPage />} />
          <Route path="/results/:attemptId" element={<Results />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/analytics" element={<Analytics />} />
        </Routes>
      </main>
    </div>
  )
}
