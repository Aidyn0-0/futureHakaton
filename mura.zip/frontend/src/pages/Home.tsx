import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { createUser, generateTest } from '../api/client'

const SUBJECTS = ['Python', 'JavaScript', 'Математика', 'Физика', 'История', 'Биология']
const DIFFICULTIES = [
  { value: 'beginner', label: 'Начальный', color: 'bg-green-100 text-green-700 border-green-300' },
  { value: 'intermediate', label: 'Средний', color: 'bg-yellow-100 text-yellow-700 border-yellow-300' },
  { value: 'advanced', label: 'Продвинутый', color: 'bg-red-100 text-red-700 border-red-300' },
]

export default function Home() {
  const navigate = useNavigate()
  const [name, setName] = useState('')
  const [subject, setSubject] = useState(SUBJECTS[0])
  const [difficulty, setDifficulty] = useState('intermediate')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleStart = async () => {
    if (!name.trim()) {
      setError('Введите ваше имя')
      return
    }
    setError('')
    setLoading(true)

    try {
      const user = await createUser(name.trim())
      localStorage.setItem('userId', String(user.id))
      localStorage.setItem('userName', user.name)

      const test = await generateTest(subject, difficulty, user.id)
      navigate(`/test/${test.id}`)
    } catch (err: any) {
      setError(err?.response?.data?.detail || 'Ошибка при создании теста')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-lg mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-slate-800 mb-2">AI-Наставник</h1>
        <p className="text-slate-500">Адаптивное тестирование с персональным AI-анализом</p>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 space-y-6">
        {/* Name */}
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Ваше имя</label>
          <input
            type="text"
            value={name}
            onChange={e => setName(e.target.value)}
            placeholder="Введите имя"
            className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none"
          />
        </div>

        {/* Subject */}
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Предмет</label>
          <select
            value={subject}
            onChange={e => setSubject(e.target.value)}
            className="w-full px-4 py-2.5 rounded-lg border border-slate-300 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none"
          >
            {SUBJECTS.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>

        {/* Difficulty */}
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-2">Сложность</label>
          <div className="flex gap-3">
            {DIFFICULTIES.map(d => (
              <button
                key={d.value}
                onClick={() => setDifficulty(d.value)}
                className={`flex-1 py-2 px-3 rounded-lg border text-sm font-medium transition-colors ${
                  difficulty === d.value ? d.color : 'bg-slate-50 text-slate-500 border-slate-200'
                }`}
              >
                {d.label}
              </button>
            ))}
          </div>
        </div>

        {error && <p className="text-red-500 text-sm">{error}</p>}

        <button
          onClick={handleStart}
          disabled={loading}
          className="w-full py-3 rounded-lg bg-indigo-600 text-white font-medium hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
        >
          {loading ? 'Генерация теста...' : 'Начать тест'}
        </button>
      </div>
    </div>
  )
}
