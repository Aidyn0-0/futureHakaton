import { useEffect, useState, useCallback } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { getTest, submitAttempt } from '../api/client'
import QuestionCard from '../components/QuestionCard'
import Timer from '../components/Timer'
import ProgressBar from '../components/ProgressBar'

interface Question {
  id: number
  type: string
  question: string
  options: string[]
}

export default function TestPage() {
  const { testId } = useParams<{ testId: string }>()
  const navigate = useNavigate()

  const [questions, setQuestions] = useState<Question[]>([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const [answers, setAnswers] = useState<Record<string, string | string[]>>({})
  const [loading, setLoading] = useState(true)
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    if (!testId) return
    getTest(Number(testId))
      .then(data => {
        setQuestions(data.questions)
        setLoading(false)
      })
      .catch(() => {
        setLoading(false)
      })
  }, [testId])

  const handleAnswer = (questionId: number, answer: string | string[]) => {
    setAnswers(prev => ({ ...prev, [String(questionId)]: answer }))
  }

  const handleSubmit = useCallback(async () => {
    if (submitting) return
    setSubmitting(true)
    const userId = localStorage.getItem('userId')
    if (!userId || !testId) return

    try {
      const result = await submitAttempt(Number(userId), Number(testId), answers)
      navigate(`/results/${result.id}`)
    } catch {
      setSubmitting(false)
    }
  }, [answers, testId, navigate, submitting])

  if (loading) {
    return <div className="text-center py-20 text-slate-400">Загрузка теста...</div>
  }

  if (questions.length === 0) {
    return <div className="text-center py-20 text-slate-400">Тест не найден</div>
  }

  const currentQuestion = questions[currentIndex]
  const answeredCount = Object.keys(answers).length

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <ProgressBar current={answeredCount} total={questions.length} />
        <div className="ml-6">
          <Timer durationSeconds={300} onTimeUp={handleSubmit} />
        </div>
      </div>

      {/* Question */}
      <QuestionCard
        question={currentQuestion}
        selectedAnswer={answers[String(currentQuestion.id)]}
        onAnswer={handleAnswer}
      />

      {/* Navigation */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => setCurrentIndex(i => Math.max(0, i - 1))}
          disabled={currentIndex === 0}
          className="px-4 py-2 rounded-lg border border-slate-300 text-slate-600 hover:bg-slate-50 disabled:opacity-30 disabled:cursor-not-allowed"
        >
          Назад
        </button>

        <div className="flex gap-1.5">
          {questions.map((q, i) => (
            <button
              key={q.id}
              onClick={() => setCurrentIndex(i)}
              className={`w-8 h-8 rounded-full text-xs font-medium transition-colors ${
                i === currentIndex
                  ? 'bg-indigo-600 text-white'
                  : answers[String(q.id)]
                    ? 'bg-indigo-100 text-indigo-700'
                    : 'bg-slate-100 text-slate-500'
              }`}
            >
              {i + 1}
            </button>
          ))}
        </div>

        {currentIndex < questions.length - 1 ? (
          <button
            onClick={() => setCurrentIndex(i => Math.min(questions.length - 1, i + 1))}
            className="px-4 py-2 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700"
          >
            Далее
          </button>
        ) : (
          <button
            onClick={handleSubmit}
            disabled={submitting}
            className="px-4 py-2 rounded-lg bg-green-600 text-white hover:bg-green-700 disabled:opacity-50"
          >
            {submitting ? 'Отправка...' : 'Завершить'}
          </button>
        )}
      </div>
    </div>
  )
}
