import { useEffect, useState } from 'react'
import { getGroupAnalytics } from '../api/client'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

interface GroupData {
  total_students: number
  total_attempts: number
  average_score: number
  subject_breakdown: Record<string, { attempts: number; avg_score: number }>
  hardest_questions: { question: string; wrong: number; total: number }[]
}

export default function Analytics() {
  const [data, setData] = useState<GroupData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    getGroupAnalytics()
      .then(setData)
      .finally(() => setLoading(false))
  }, [])

  if (loading) return <div className="text-center py-20 text-slate-400">Загрузка аналитики...</div>
  if (!data) return <div className="text-center py-20 text-slate-400">Нет данных</div>

  const subjectData = Object.entries(data.subject_breakdown).map(([subject, info]) => ({
    subject,
    avg_score: info.avg_score,
    attempts: info.attempts,
  }))

  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-bold text-slate-800">Панель преподавателя</h1>

      {/* KPI Cards */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 text-center">
          <p className="text-3xl font-bold text-indigo-600">{data.total_students}</p>
          <p className="text-sm text-slate-500 mt-1">Студентов</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 text-center">
          <p className="text-3xl font-bold text-indigo-600">{data.total_attempts}</p>
          <p className="text-sm text-slate-500 mt-1">Попыток</p>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6 text-center">
          <p className="text-3xl font-bold text-indigo-600">{data.average_score}%</p>
          <p className="text-sm text-slate-500 mt-1">Средний балл</p>
        </div>
      </div>

      {/* Subject breakdown chart */}
      {subjectData.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h3 className="font-semibold text-slate-700 mb-4">Средний балл по предметам</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={subjectData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="subject" tick={{ fontSize: 12 }} />
              <YAxis domain={[0, 100]} tick={{ fontSize: 12 }} />
              <Tooltip />
              <Bar dataKey="avg_score" fill="#6366f1" radius={[4, 4, 0, 0]} name="Средний балл" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Hardest questions */}
      {data.hardest_questions.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h3 className="font-semibold text-slate-700 mb-4">Самые сложные вопросы</h3>
          <div className="space-y-3">
            {data.hardest_questions.map((q, i) => (
              <div key={i} className="flex items-start gap-3 p-3 bg-red-50 rounded-lg">
                <span className="bg-red-200 text-red-700 text-xs font-bold w-6 h-6 rounded-full flex items-center justify-center shrink-0">
                  {i + 1}
                </span>
                <div>
                  <p className="text-sm text-slate-800">{q.question}</p>
                  <p className="text-xs text-red-500 mt-1">
                    Ошибок: {q.wrong} из {q.total} попыток
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
