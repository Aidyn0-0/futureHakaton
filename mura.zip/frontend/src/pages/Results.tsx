import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { getAttempt } from '../api/client'

interface MistakeAnalysis {
  question_id: number
  question: string
  student_answer: string | string[]
  correct_answer: string | string[]
  explanation: string
  theory: string
  micro_tasks: string[]
}

interface AttemptData {
  id: number
  score: number
  mistakes_analysis: MistakeAnalysis[]
  homework: { question_id: number; task: string }[]
}

export default function Results() {
  const { attemptId } = useParams<{ attemptId: string }>()
  const [data, setData] = useState<AttemptData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!attemptId) return
    getAttempt(Number(attemptId))
      .then(setData)
      .finally(() => setLoading(false))
  }, [attemptId])

  if (loading) return <div className="text-center py-20 text-slate-400">Загрузка результатов...</div>
  if (!data) return <div className="text-center py-20 text-slate-400">Результат не найден</div>

  const scoreColor = data.score >= 80 ? 'text-green-600' : data.score >= 50 ? 'text-yellow-600' : 'text-red-600'

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      {/* Score */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-8 text-center">
        <p className="text-sm text-slate-500 mb-2">Ваш результат</p>
        <p className={`text-6xl font-bold ${scoreColor}`}>{data.score}%</p>
        <p className="text-slate-500 mt-2">
          {data.score >= 80 ? 'Отличный результат!' : data.score >= 50 ? 'Есть над чем поработать' : 'Рекомендуем повторить материал'}
        </p>
      </div>

      {/* Mistakes Analysis */}
      {data.mistakes_analysis.length > 0 && (
        <div>
          <h2 className="text-xl font-semibold text-slate-800 mb-4">Разбор ошибок</h2>
          <div className="space-y-4">
            {data.mistakes_analysis.map((m, i) => (
              <div key={i} className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
                <h3 className="font-medium text-slate-800 mb-3">{m.question}</h3>

                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="bg-red-50 rounded-lg p-3">
                    <p className="text-xs text-red-500 mb-1">Ваш ответ</p>
                    <p className="text-sm text-red-700 font-medium">
                      {Array.isArray(m.student_answer) ? m.student_answer.join(', ') : m.student_answer}
                    </p>
                  </div>
                  <div className="bg-green-50 rounded-lg p-3">
                    <p className="text-xs text-green-500 mb-1">Правильный ответ</p>
                    <p className="text-sm text-green-700 font-medium">
                      {Array.isArray(m.correct_answer) ? m.correct_answer.join(', ') : m.correct_answer}
                    </p>
                  </div>
                </div>

                <div className="bg-blue-50 rounded-lg p-4 mb-3">
                  <p className="text-xs text-blue-500 mb-1 font-medium">Объяснение</p>
                  <p className="text-sm text-blue-800">{m.explanation}</p>
                </div>

                <div className="bg-purple-50 rounded-lg p-4 mb-3">
                  <p className="text-xs text-purple-500 mb-1 font-medium">Теория</p>
                  <p className="text-sm text-purple-800">{m.theory}</p>
                </div>

                {m.micro_tasks.length > 0 && (
                  <div className="bg-amber-50 rounded-lg p-4">
                    <p className="text-xs text-amber-600 mb-2 font-medium">Задания для закрепления</p>
                    <ul className="space-y-1">
                      {m.micro_tasks.map((task, j) => (
                        <li key={j} className="text-sm text-amber-800 flex gap-2">
                          <span className="text-amber-400">•</span>
                          {task}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="flex gap-4 justify-center">
        <Link
          to="/"
          className="px-6 py-3 rounded-lg bg-indigo-600 text-white font-medium hover:bg-indigo-700 transition-colors"
        >
          Новый тест
        </Link>
        <Link
          to="/dashboard"
          className="px-6 py-3 rounded-lg border border-slate-300 text-slate-600 font-medium hover:bg-slate-50 transition-colors"
        >
          Мой прогресс
        </Link>
      </div>
    </div>
  )
}
