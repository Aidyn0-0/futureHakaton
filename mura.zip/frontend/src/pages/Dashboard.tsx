import { useEffect, useState } from 'react'
import { getUserAttempts } from '../api/client'
import RadarChart from '../components/RadarChart'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'

interface Attempt {
  id: number
  test_id: number
  score: number
  status: string
  created_at: string
  mistakes_analysis: any[]
}

export default function Dashboard() {
  const [attempts, setAttempts] = useState<Attempt[]>([])
  const [loading, setLoading] = useState(true)

  const userId = localStorage.getItem('userId')
  const userName = localStorage.getItem('userName') || 'Студент'

  useEffect(() => {
    if (!userId) {
      setLoading(false)
      return
    }
    getUserAttempts(Number(userId))
      .then(setAttempts)
      .finally(() => setLoading(false))
  }, [userId])

  if (!userId) {
    return (
      <div className="text-center py-20">
        <p className="text-slate-400">Для просмотра кабинета сначала пройдите тест</p>
      </div>
    )
  }

  if (loading) return <div className="text-center py-20 text-slate-400">Загрузка...</div>

  // Prepare chart data
  const progressData = [...attempts]
    .reverse()
    .map((a, i) => ({
      name: `Тест ${i + 1}`,
      score: a.score,
    }))

  // Aggregate by subject (from attempt -> test relationship)
  const subjectScores: Record<string, { total: number; count: number }> = {}
  for (const a of attempts) {
    // We don't have subject directly, using test_id as proxy
    const key = `Тест #${a.test_id}`
    if (!subjectScores[key]) subjectScores[key] = { total: 0, count: 0 }
    subjectScores[key].total += a.score
    subjectScores[key].count += 1
  }

  const radarData = Object.entries(subjectScores).map(([subject, { total, count }]) => ({
    subject,
    score: Math.round(total / count),
  }))

  const avgScore = attempts.length > 0
    ? Math.round(attempts.reduce((s, a) => s + a.score, 0) / attempts.length)
    : 0

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-slate-800">Кабинет: {userName}</h1>
        <p className="text-slate-500">Всего попыток: {attempts.length} | Средний балл: {avgScore}%</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Progress Chart */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h3 className="font-semibold text-slate-700 mb-4">Прогресс</h3>
          {progressData.length > 0 ? (
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={progressData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" tick={{ fontSize: 12 }} />
                <YAxis domain={[0, 100]} tick={{ fontSize: 12 }} />
                <Tooltip />
                <Line type="monotone" dataKey="score" stroke="#6366f1" strokeWidth={2} dot={{ r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <p className="text-slate-400 text-sm text-center py-8">Нет данных</p>
          )}
        </div>

        {/* Radar */}
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h3 className="font-semibold text-slate-700 mb-4">Результаты по темам</h3>
          <RadarChart data={radarData} />
        </div>
      </div>

      {/* History */}
      <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
        <h3 className="font-semibold text-slate-700 mb-4">История попыток</h3>
        {attempts.length === 0 ? (
          <p className="text-slate-400 text-sm">Пока нет попыток</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-left text-slate-500 border-b border-slate-200">
                  <th className="pb-2 font-medium">#</th>
                  <th className="pb-2 font-medium">Дата</th>
                  <th className="pb-2 font-medium">Баллы</th>
                  <th className="pb-2 font-medium">Ошибки</th>
                </tr>
              </thead>
              <tbody>
                {attempts.map((a, i) => (
                  <tr key={a.id} className="border-b border-slate-100">
                    <td className="py-2 text-slate-600">{i + 1}</td>
                    <td className="py-2 text-slate-600">{new Date(a.created_at).toLocaleDateString('ru')}</td>
                    <td className="py-2">
                      <span className={`font-medium ${a.score >= 80 ? 'text-green-600' : a.score >= 50 ? 'text-yellow-600' : 'text-red-600'}`}>
                        {a.score}%
                      </span>
                    </td>
                    <td className="py-2 text-slate-600">{a.mistakes_analysis?.length || 0}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
