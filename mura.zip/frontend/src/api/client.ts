import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
})

// --- Users ---
export const createUser = (name: string, role = 'student') =>
  api.post('/users', { name, role }).then(r => r.data)

// --- Tests ---
export const generateTest = (subject: string, difficulty: string, userId?: number) =>
  api.post('/tests/generate', { subject, difficulty, user_id: userId }).then(r => r.data)

export const getTest = (testId: number) =>
  api.get(`/tests/${testId}`).then(r => r.data)

// --- Attempts ---
export const submitAttempt = (userId: number, testId: number, answers: Record<string, string | string[]>) =>
  api.post('/attempts/submit', { user_id: userId, test_id: testId, answers }).then(r => r.data)

export const getAttempt = (attemptId: number) =>
  api.get(`/attempts/${attemptId}`).then(r => r.data)

export const getUserAttempts = (userId: number) =>
  api.get(`/attempts/user/${userId}`).then(r => r.data)

// --- Analytics ---
export const getGroupAnalytics = () =>
  api.get('/analytics/group').then(r => r.data)

export default api
