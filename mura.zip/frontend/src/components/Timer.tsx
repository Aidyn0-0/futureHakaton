import { useEffect, useState } from 'react'

interface TimerProps {
  durationSeconds: number
  onTimeUp: () => void
}

export default function Timer({ durationSeconds, onTimeUp }: TimerProps) {
  const [secondsLeft, setSecondsLeft] = useState(durationSeconds)

  useEffect(() => {
    if (secondsLeft <= 0) {
      onTimeUp()
      return
    }
    const timer = setTimeout(() => setSecondsLeft(s => s - 1), 1000)
    return () => clearTimeout(timer)
  }, [secondsLeft, onTimeUp])

  const mins = Math.floor(secondsLeft / 60)
  const secs = secondsLeft % 60
  const isLow = secondsLeft < 60

  return (
    <div className={`font-mono text-lg font-semibold ${isLow ? 'text-red-500' : 'text-slate-700'}`}>
      {String(mins).padStart(2, '0')}:{String(secs).padStart(2, '0')}
    </div>
  )
}
