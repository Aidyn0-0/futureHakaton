interface Question {
  id: number
  type: string
  question: string
  options: string[]
}

interface QuestionCardProps {
  question: Question
  selectedAnswer: string | string[] | undefined
  onAnswer: (questionId: number, answer: string | string[]) => void
}

export default function QuestionCard({ question, selectedAnswer, onAnswer }: QuestionCardProps) {
  const isMultiple = question.type === 'multiple_choice'

  const handleSelect = (option: string) => {
    if (isMultiple) {
      const current = Array.isArray(selectedAnswer) ? selectedAnswer : []
      const updated = current.includes(option)
        ? current.filter(o => o !== option)
        : [...current, option]
      onAnswer(question.id, updated)
    } else {
      onAnswer(question.id, option)
    }
  }

  const isSelected = (option: string) => {
    if (isMultiple && Array.isArray(selectedAnswer)) {
      return selectedAnswer.includes(option)
    }
    return selectedAnswer === option
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
      <div className="flex items-start gap-3 mb-4">
        <span className="bg-indigo-100 text-indigo-700 text-xs font-medium px-2 py-1 rounded">
          {isMultiple ? 'Несколько ответов' : 'Один ответ'}
        </span>
      </div>
      <h3 className="text-lg font-medium text-slate-800 mb-4">{question.question}</h3>
      <div className="space-y-2">
        {question.options.map((option) => (
          <button
            key={option}
            onClick={() => handleSelect(option)}
            className={`w-full text-left px-4 py-3 rounded-lg border transition-colors ${
              isSelected(option)
                ? 'border-indigo-500 bg-indigo-50 text-indigo-700'
                : 'border-slate-200 hover:border-slate-300 text-slate-700'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className={`w-5 h-5 rounded-${isMultiple ? 'md' : 'full'} border-2 flex items-center justify-center ${
                isSelected(option)
                  ? 'border-indigo-500 bg-indigo-500'
                  : 'border-slate-300'
              }`}>
                {isSelected(option) && (
                  <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                )}
              </div>
              {option}
            </div>
          </button>
        ))}
      </div>
    </div>
  )
}
