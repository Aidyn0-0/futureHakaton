# AI-Наставник

Платформа адаптивного тестирования с AI-наставником. Генерирует тесты по любому предмету, анализирует ошибки студентов и выдаёт персональные рекомендации с дополнительными заданиями.

## Возможности

- **Генерация тестов** — AI создаёт уникальные тесты по выбранному предмету и уровню сложности (GPT-4o)
- **Адаптивность** — система исключает ранее заданные вопросы, чтобы не повторяться
- **Анализ ошибок** — для каждой ошибки AI объясняет, почему ответ неверный, даёт теорию и мини-задания
- **Личный кабинет** — графики прогресса, radar chart по темам, история попыток
- **Панель преподавателя** — аналитика по группе, средний балл по предметам, топ сложных вопросов

## Стек

| Слой | Технологии |
|------|-----------|
| Backend | FastAPI, SQLAlchemy, SQLite |
| Frontend | React, TypeScript, Vite, Tailwind CSS, Recharts |
| AI | OpenAI GPT-4o (с локальным fallback) |

## Быстрый старт

### 1. Backend

```bash
cd backend
pip install -r requirements.txt
```

Создайте файл `.env` в папке `backend/`:

```
OPENAI_API_KEY=sk-your-key-here
```

Запуск:

```bash
uvicorn main:app --reload
```

API доступен на http://localhost:8000 — документация на http://localhost:8000/docs

### 2. Frontend

```bash
cd frontend
npm install
npm run dev
```

Откройте http://localhost:5173

## API

| Метод | Путь | Описание |
|-------|------|----------|
| POST | `/api/users` | Создать пользователя |
| GET | `/api/users` | Список пользователей |
| POST | `/api/tests/generate` | Сгенерировать тест |
| GET | `/api/tests/{id}` | Получить тест (без ответов) |
| POST | `/api/attempts/submit` | Отправить ответы |
| GET | `/api/attempts/{id}` | Результат попытки |
| GET | `/api/attempts/user/{id}` | История попыток студента |
| GET | `/api/analytics/group` | Аналитика по группе |

## Структура проекта

```
mura/
├── backend/
│   ├── main.py                # FastAPI-приложение
│   ├── database.py            # SQLAlchemy, подключение к SQLite
│   ├── models.py              # ORM: User, Test, Attempt
│   ├── schemas.py             # Pydantic-схемы
│   ├── routers/
│   │   ├── tests.py           # Генерация и получение тестов
│   │   ├── attempts.py        # Отправка ответов, результаты
│   │   └── analytics.py       # Аналитика для преподавателя
│   └── services/
│       ├── ai_generator.py    # Генерация тестов через GPT-4o
│       └── ai_analyzer.py     # Анализ ошибок через GPT-4o
└── frontend/
    └── src/
        ├── App.tsx            # Роутинг
        ├── api/client.ts      # HTTP-клиент
        ├── pages/
        │   ├── Home.tsx       # Выбор предмета и сложности
        │   ├── TestPage.tsx   # Прохождение теста
        │   ├── Results.tsx    # Результаты + разбор ошибок
        │   ├── Dashboard.tsx  # Личный кабинет студента
        │   └── Analytics.tsx  # Панель преподавателя
        └── components/
            ├── QuestionCard.tsx
            ├── Timer.tsx
            ├── ProgressBar.tsx
            └── RadarChart.tsx
```

## Без ключа OpenAI

Если API-ключ недействителен или нет баланса — приложение продолжает работать: тесты берутся из встроенного банка вопросов (Python, JavaScript, Математика), анализ ошибок формируется локально.
