from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

import database
from database import Base, get_db
from models import User
from schemas import UserCreate, UserOut
from routers import tests, attempts, analytics, auth
from configuration.сonfiguration import Config
from services import ai_generator, ai_analyzer


DATABASE_URL = "sqlite:///./mura.db"
GoogleGeminiToken = "AIzaSyBOQWnayRBa50zYlgdi25DA4qVboxRpfII"
GoogleGeminiVersion = "gemini-2.5-flash"

def init_config():
    config = Config()

    import inspect
    frame = inspect.currentframe().f_back
    global_dict = frame.f_globals

    globals_list = [
        ('DataBaseLink', 'DATABASE_URL'),
        ('GoogleGemini.Token', 'GoogleGeminiToken'),
        ('GoogleGemini.Version', 'GoogleGeminiVersion'),

        #('boxZone.h', 'boxZone_h'),
        #('boxZone.w', 'boxZone_w'),
        #('boxZone.x', 'boxZone_x'),
        #('boxZone.y', 'boxZone_y'),
    ]

    changes_made = False

    for config_path, var_name in globals_list:
        if not config.contains(config_path):
            config.set(config_path, globals()[var_name])
            changes_made = True
        else:
            global_dict[var_name] = config.get(config_path)

    if changes_made:
        config.save()

    return config
config = init_config()

database.configure_db(DATABASE_URL)
Base.metadata.create_all(bind=database.engine)

ai_generator.configure_api(GoogleGeminiToken, GoogleGeminiVersion)
ai_analyzer.configure_api(GoogleGeminiToken, GoogleGeminiVersion)

app = FastAPI(title="AI-Tests", version="1.0.0")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routers
app.include_router(tests.router)
app.include_router(attempts.router)
app.include_router(analytics.router)
app.include_router(auth.router)

@app.get("/")
def root():
    return {"message": "AI-Tests API", "docs": "/docs"}


@app.post("/api/users", response_model=UserOut)
def create_user(req: UserCreate, db: Session = Depends(get_db)):
    user = User(name=req.name, role=req.role)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@app.get("/api/users", response_model=list[UserOut])
def list_users(db: Session = Depends(get_db)):
    return db.query(User).all()
