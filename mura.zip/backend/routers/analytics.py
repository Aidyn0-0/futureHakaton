from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func

from database import get_db
from models import Attempt, Test, User
from schemas import GroupAnalytics

router = APIRouter(prefix="/api/analytics", tags=["analytics"])


@router.get("/group", response_model=GroupAnalytics)
def group_analytics(db: Session = Depends(get_db)):
    total_students = db.query(User).filter(User.role == "student").count()
    total_attempts = db.query(Attempt).filter(Attempt.status == "completed").count()

    avg_score_result = (
        db.query(func.avg(Attempt.score))
        .filter(Attempt.status == "completed")
        .scalar()
    )
    average_score = round(avg_score_result, 1) if avg_score_result else 0

    # Score breakdown by subject
    subject_stats = (
        db.query(
            Test.subject,
            func.count(Attempt.id).label("attempts"),
            func.avg(Attempt.score).label("avg_score"),
        )
        .join(Test, Attempt.test_id == Test.id)
        .filter(Attempt.status == "completed")
        .group_by(Test.subject)
        .all()
    )
    subject_breakdown = {}
    for row in subject_stats:
        subject_breakdown[row.subject] = {
            "attempts": row.attempts,
            "avg_score": round(row.avg_score, 1) if row.avg_score else 0,
        }

    # Find hardest questions (most frequently missed)
    hardest_questions = _find_hardest_questions(db)

    return GroupAnalytics(
        total_students=total_students,
        total_attempts=total_attempts,
        average_score=average_score,
        subject_breakdown=subject_breakdown,
        hardest_questions=hardest_questions,
    )


def _find_hardest_questions(db: Session, limit: int = 5) -> list[dict]:
    """Scan completed attempts and find questions with the lowest success rate."""
    attempts = db.query(Attempt).filter(Attempt.status == "completed").all()

    question_stats: dict[str, dict] = {}  # question_text -> {total, wrong}

    for attempt in attempts:
        if not attempt.mistakes_analysis:
            continue
        for mistake in attempt.mistakes_analysis:
            q_text = mistake.get("question", "")
            if q_text not in question_stats:
                question_stats[q_text] = {"total": 0, "wrong": 0, "question": q_text}
            question_stats[q_text]["wrong"] += 1

    # Also count total appearances
    tests = db.query(Test).all()
    for test in tests:
        if not test.questions:
            continue
        attempt_count = db.query(Attempt).filter(
            Attempt.test_id == test.id, Attempt.status == "completed"
        ).count()
        for q in test.questions:
            q_text = q.get("question", "")
            if q_text in question_stats:
                question_stats[q_text]["total"] = attempt_count

    # Sort by error rate
    sorted_questions = sorted(
        question_stats.values(),
        key=lambda x: x["wrong"] / max(x["total"], 1),
        reverse=True,
    )

    return sorted_questions[:limit]
