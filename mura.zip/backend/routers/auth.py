from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from datetime import datetime, timedelta

from database import get_db
from models import User
from schemas import RegisterRequest, LoginRequest, AuthOut

from passlib.context import CryptContext



pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
SECRET_KEY = "gaopibevbwodovwdmomlpsgwveewv"
def hash_passwd(passwd: str) -> str:
    return pwd_context.hash(passwd)

def verify_passwd(plain: str, hashed: str) -> bool:
    return pwd_context.verify(plain, hashed)


import jwt
def create_token(user_id: int) -> str:
    payload = {
        "user_id": user_id,
        "exp": datetime.utcnow() + timedelta(days=1)   # токен живёт 1 днь
    }
    return jwt.encode(payload, SECRET_KEY, algorithm="HS256")



router = APIRouter(prefix="/api/auth", tags=["auth"])

@router.post("/register", response_model=AuthOut)
def register(req: RegisterRequest, db: Session = Depends(get_db)):
    print("registred")

@router.post("/login", response_model=AuthOut)
def login(req: LoginRequest, db: Session = Depends(get_db)):
    print("logined")