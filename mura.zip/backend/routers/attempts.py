from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from database import get_db
from models import Attempt, Test, User
from schemas import AttemptSubmit, AttemptOut
from services.ai_analyzer import analyze_results

router = APIRouter(prefix="/api/attempts", tags=["attempts"])


@router.post("/submit", response_model=AttemptOut)
def submit_attempt(req: AttemptSubmit, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == req.user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    test = db.query(Test).filter(Test.id == req.test_id).first()
    if not test:
        raise HTTPException(status_code=404, detail="Test not found")

    # Analyze with AI
    result = analyze_results(test.questions, req.answers)

    attempt = Attempt(
        user_id=req.user_id,
        test_id=req.test_id,
        answers=req.answers,
        score=result["score"],
        mistakes_analysis=result["mistakes_analysis"],
        homework=result["homework"],
        status="completed",
    )
    db.add(attempt)
    db.commit()
    db.refresh(attempt)
    return attempt


@router.get("/{attempt_id}", response_model=AttemptOut)
def get_attempt(attempt_id: int, db: Session = Depends(get_db)):
    attempt = db.query(Attempt).filter(Attempt.id == attempt_id).first()
    if not attempt:
        raise HTTPException(status_code=404, detail="Attempt not found")
    return attempt


@router.get("/user/{user_id}", response_model=list[AttemptOut])
def get_user_attempts(user_id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    attempts = (
        db.query(Attempt)
        .filter(Attempt.user_id == user_id)
        .order_by(Attempt.created_at.desc())
        .all()
    )
    return attempts
