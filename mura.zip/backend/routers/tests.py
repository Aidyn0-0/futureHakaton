from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from database import get_db
from models import Test, User, Attempt
from schemas import TestGenerateRequest, TestOut, TestForStudent
from services.ai_generator import generate_test

router = APIRouter(prefix="/api/tests", tags=["tests"])


@router.post("/generate", response_model=TestOut)
def generate_test_endpoint(req: TestGenerateRequest, db: Session = Depends(get_db)):
    # Gather previously asked questions to avoid repeats
    exclude_questions: list[str] = []
    if req.user_id:
        user = db.query(User).filter(User.id == req.user_id).first()
        if not user:
            raise HTTPException(status_code=404, detail="User not found")

        previous_attempts = (
            db.query(Attempt)
            .join(Test)
            .filter(Attempt.user_id == req.user_id, Test.subject == req.subject)
            .all()
        )
        for attempt in previous_attempts:
            test = db.query(Test).filter(Test.id == attempt.test_id).first()
            if test and test.questions:
                for q in test.questions:
                    exclude_questions.append(q.get("question", ""))

    # Generate via AI
    result = generate_test(req.subject, req.difficulty, exclude_questions or None)
    questions = result.get("questions", [])

    # Save to DB
    test = Test(
        subject=req.subject,
        difficulty=req.difficulty,
        questions=questions,
    )
    db.add(test)
    db.commit()
    db.refresh(test)
    return test


@router.get("/{test_id}", response_model=TestForStudent)
def get_test(test_id: int, db: Session = Depends(get_db)):
    test = db.query(Test).filter(Test.id == test_id).first()
    if not test:
        raise HTTPException(status_code=404, detail="Test not found")

    # Strip correct answers and explanations for the student
    sanitized_questions = []
    for q in test.questions:
        sanitized_questions.append({
            "id": q["id"],
            "type": q["type"],
            "question": q["question"],
            "options": q["options"],
        })

    return TestForStudent(
        id=test.id,
        subject=test.subject,
        difficulty=test.difficulty,
        questions=sanitized_questions,
    )
