from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase

DATABASE_URL = "sqlite:///./mura.db"

engine = None
SessionLocal = None
def get_engine():
    return engine

def get_sessionLocal():
    return SessionLocal
def configure_db(url: str):
    global DATABASE_URL, engine, SessionLocal
    DATABASE_URL = url
    engine = create_engine(url, connect_args={"check_same_thread": False})
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

class Base(DeclarativeBase):
    pass