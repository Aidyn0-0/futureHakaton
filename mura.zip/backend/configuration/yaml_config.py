import yaml
from configuration.base_config import BaseConfig


class YamlConfig(BaseConfig):
    def __init__(self, name: str = "config.yml"):
        super().__init__(name)

    def save(self):
        with open(self.name, 'w') as f:
            yaml.dump(self.data, f, default_flow_style=False)

    def load(self) -> dict:
        try:
            with open(self.name, 'r') as f:
                data = yaml.safe_load(f) or {}
                self.data = data
                return data
        except FileNotFoundError:
            print(f"Warning: {self.name} file contains incorrect YAML.")
            self.data = {}
            return {}