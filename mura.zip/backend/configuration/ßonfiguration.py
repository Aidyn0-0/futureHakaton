import os
import json
import yaml
from configuration.base_config import BaseConfig
from configuration.json_config import JsonConfig
from configuration.yaml_config import YamlConfig


CONFIG_TYPE_KEY = "configuration_file_type"


class Config:

    SUPPORTED = {
        "json": JsonConfig,
        "yml":  YamlConfig,
        "yaml": YamlConfig,
    }

    def __init__(self, name: str = "config.json"):
        self.name = name
        self._impl: BaseConfig = self._load_impl(name)

    def _ext(self, filename: str) -> str:
        return os.path.splitext(filename)[1].lstrip('.').lower()

    def _base(self, filename: str) -> str:
        return os.path.splitext(filename)[0]

    def _find_existing_file(self, name: str) -> str | None:
        base = self._base(name)
        # Сначала проверяем точное имя
        if os.path.exists(name) and self._ext(name) in self.SUPPORTED:
            return name
        for ext in self.SUPPORTED:
            candidate = f"{base}.{ext}"
            if candidate != name and os.path.exists(candidate):
                return candidate
        return None

    def _build_impl(self, filename: str) -> BaseConfig:
        ext = self._ext(filename)
        cls = self.SUPPORTED.get(ext)
        if cls is None:
            raise ValueError(f"Неподдерживаемый формат файла: '{ext}'. "
                             f"Используйте: {list(self.SUPPORTED)}")
        return cls(filename)

    def _load_impl(self, name: str) -> BaseConfig:
        existing = self._find_existing_file(name)

        if existing is None:
            impl = self._build_impl(name)
            impl.set(CONFIG_TYPE_KEY, self._ext(name))
            impl.save()
            self.name = name
            return impl

        impl = self._build_impl(existing)
        self.name = existing

        if not impl.contains(CONFIG_TYPE_KEY):
            impl.set(CONFIG_TYPE_KEY, self._ext(existing))
            impl.save()
            return impl

        declared_type = impl.get(CONFIG_TYPE_KEY)
        file_ext      = self._ext(existing)

        if declared_type and declared_type != file_ext:
            impl = self._convert(impl, declared_type)

        return impl

    def _new_filename(self, old_name: str, new_ext: str) -> str:
        base = self._base(old_name)
        return f"{base}.{new_ext}"

    def _convert(self, old_impl: BaseConfig, new_type: str) -> BaseConfig:
        old_file = old_impl.name
        new_file = self._new_filename(old_file, new_type)

        print(f"[Config] Обнаружена смена типа: "
              f"'{self._ext(old_file)}' → '{new_type}'. "
              f"Конвертирую {old_file!r} → {new_file!r}")

        data_to_migrate = dict(old_impl.data)
        data_to_migrate[CONFIG_TYPE_KEY] = new_type

        new_impl = self._build_impl(new_file)
        new_impl.data = data_to_migrate
        new_impl.save()

        if os.path.exists(old_file):
            os.remove(old_file)
            print(f"[Config] Старый файл {old_file!r} удалён.")

        self.name = new_file
        return new_impl

    def save(self):
        declared = self._impl.get(CONFIG_TYPE_KEY)
        current_ext = self._ext(self._impl.name)
        if declared and declared != current_ext:
            self._impl = self._convert(self._impl, declared)
        else:
            self._impl.save()

    def load(self) -> dict:
        return self._impl.load()

    def set(self, data_path: str, value):
        self._impl.set(data_path, value)

    def get(self, data_path: str):
        return self._impl.get(data_path)

    def contains(self, data_path: str) -> bool:
        return self._impl.contains(data_path)

    def get_keys(self, data_path: str = '', include_subkeys: bool = False) -> list:
        return self._impl.get_keys(data_path, include_subkeys)