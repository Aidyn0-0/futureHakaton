import json
from configuration.base_config import BaseConfig


class JsonConfig(BaseConfig):

    def __init__(self, name: str = "config.json"):
        super().__init__(name)

    def save(self):
        with open(self.name, 'w') as f:
            json.dump(self.data, f, indent=4)

    def load(self) -> dict:
        try:
            with open(self.name, 'r') as f:
                content = f.read().strip()
                data = json.loads(content) if content else {}
                self.data = data or {}
                return self.data
        except FileNotFoundError:
            self.data = {}
            return {}
        except json.JSONDecodeError:
            print(f"Warning: {self.name} file contains incorrect JSON.")
            self.data = {}
            return {}