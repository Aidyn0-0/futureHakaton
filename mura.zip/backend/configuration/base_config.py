import os
from abc import ABC, abstractmethod


class BaseConfig(ABC):
    def __init__(self, name: str):
        self.data = {}
        self.name = name
        BaseConfig.create_dir(BaseConfig.back_dir(name))
        self.load()

    @staticmethod
    def back_dir(file_path: str) -> str:
        parts = file_path.split("/")
        return "/".join(parts[:-1]) + "/" if len(parts) > 1 else ""

    @staticmethod
    def create_dir(path: str):
        if path and not os.path.exists(path):
            os.makedirs(path)

    @abstractmethod
    def save(self):
        ...
    @abstractmethod
    def load(self) -> dict:
        ...

    def set(self, data_path: str, data_to_set):
        parts = data_path.split('.')
        current = self.data
        for part in parts[:-1]:
            current = current.setdefault(part, {})
        if isinstance(current, dict):
            current[parts[-1]] = data_to_set

    def get(self, data_path: str):
        parts = data_path.split('.')
        current = self.data
        for part in parts[:-1]:
            if not isinstance(current, dict):
                return None
            current = current.get(part)
            if current is None:
                return None
        if isinstance(current, dict) and parts[-1] in current:
            return current[parts[-1]]
        return None

    def contains(self, data_path: str) -> bool:
        parts = data_path.split('.')
        current = self.data
        for part in parts[:-1]:
            if not isinstance(current, dict):
                return False
            current = current.get(part)
            if current is None:
                return False
        return isinstance(current, dict) and parts[-1] in current

    def get_keys(self, data_path: str = '', include_subkeys: bool = False) -> list:
        parts = data_path.split('.') if data_path else []
        current = self.data
        for part in parts:
            if not isinstance(current, dict):
                return []
            current = current.get(part)
            if current is None:
                return []

        keys = []
        if isinstance(current, dict):
            for key in current:
                if include_subkeys and isinstance(current[key], dict):
                    subkeys = self.get_keys(f"{data_path}.{key}" if data_path else key, include_subkeys)
                    keys.extend([f"{key}.{subkey}" for subkey in subkeys])
                keys.append(key)
        return keys