from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel


# --- User ---
class UserCreate(BaseModel):
    name: str
    role: str = "student"


class UserOut(BaseModel):
    id: int
    name: str
    role: str
    created_at: datetime

    model_config = {"from_attributes": True}


# --- Test ---
class TestGenerateRequest(BaseModel):
    subject: str
    difficulty: str  # beginner / intermediate / advanced
    user_id: int | None = None


class QuestionOut(BaseModel):
    id: int
    type: str
    question: str
    options: list[str]
    correct_answer: str | list[str] | None = None
    explanation: str | None = None


class TestOut(BaseModel):
    id: int
    subject: str
    difficulty: str
    questions: list[dict[str, Any]]
    created_at: datetime

    model_config = {"from_attributes": True}


class TestForStudent(BaseModel):
    """Test without correct answers — sent to the frontend during the test."""
    id: int
    subject: str
    difficulty: str
    questions: list[dict[str, Any]]

    model_config = {"from_attributes": True}


# --- Attempt ---
class AttemptSubmit(BaseModel):
    user_id: int
    test_id: int
    answers: dict[str, str | list[str]]  # question_id -> answer(s)


class MistakeAnalysis(BaseModel):
    question_id: int
    question: str
    student_answer: str | list[str]
    correct_answer: str | list[str]
    explanation: str
    theory: str
    micro_tasks: list[str]


class AttemptOut(BaseModel):
    id: int
    user_id: int
    test_id: int
    answers: dict[str, Any] | None
    score: float | None
    mistakes_analysis: list[dict[str, Any]] | None
    homework: list[dict[str, Any]] | None
    status: str
    created_at: datetime

    model_config = {"from_attributes": True}


# --- Analytics ---
class GroupAnalytics(BaseModel):
    total_students: int
    total_attempts: int
    average_score: float
    subject_breakdown: dict[str, Any]
    hardest_questions: list[dict[str, Any]]


# --- Auth ---

class RegisterRequest(BaseModel):
    name: str
    passwd: str
    role: str = "student"             # необязательно, по умолчанию студент


class LoginRequest(BaseModel):
    name: str
    passwd: str


class AuthOut(BaseModel):
    id: int
    name: str
    role: str
    token: str                        # JWT-токен для авторизации

    model_config = {"from_attributes": True}







