import json
import os
import random
import logging

import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)

_gemini_model_name: str = "gemini-2.5-flash"

def configure_api(token: str, model_version: str) -> None:
    global _gemini_model_name
    genai.configure(api_key=token)
    _gemini_model_name = model_version

SYSTEM_PROMPT = """Ты — генератор образовательных тестов. Создавай тесты строго в JSON-формате.

Правила:
1. Генерируй ровно 10 вопросов.
2. Миксуй типы: 6 вопросов single_choice и 4 вопроса multiple_choice.
3. Для single_choice — correct_answer это строка (один из options).
4. Для multiple_choice — correct_answer это массив строк (подмножество options).
5. У каждого вопроса должно быть 4 варианта ответа.
6. Добавляй explanation — краткое объяснение правильного ответа.
7. Вопросы должны соответствовать указанному предмету и уровню сложности.
8. Все тексты на русском языке.

Уровни сложности:
- beginner: базовые понятия, определения
- intermediate: применение знаний, анализ
- advanced: сложные задачи, нестандартные ситуации

Отвечай ТОЛЬКО валидным JSON без markdown-обёртки."""

# ---------------------------------------------------------------------------
# Fallback question banks (used when Gemini API is unavailable)
# ---------------------------------------------------------------------------
FALLBACK_QUESTIONS: dict[str, list[dict]] = {
    "Python": [
        {"id": 1, "type": "single_choice", "question": "Что вернёт выражение len([1, [2, 3], 4])?", "options": ["2", "3", "4", "5"], "correct_answer": "3", "explanation": "Список содержит 3 элемента: 1, [2,3] и 4."},
        {"id": 2, "type": "single_choice", "question": "Какой тип данных возвращает функция input() в Python 3?", "options": ["int", "str", "float", "bytes"], "correct_answer": "str", "explanation": "Функция input() всегда возвращает строку (str)."},
        {"id": 3, "type": "single_choice", "question": "Что выведет print(type(3.14))?", "options": ["<class 'int'>", "<class 'float'>", "<class 'str'>", "<class 'double'>"], "correct_answer": "<class 'float'>", "explanation": "3.14 — число с плавающей точкой, тип float."},
        {"id": 4, "type": "multiple_choice", "question": "Какие из типов данных являются изменяемыми (mutable) в Python?", "options": ["list", "tuple", "dict", "str"], "correct_answer": ["list", "dict"], "explanation": "list и dict — mutable, tuple и str — immutable."},
        {"id": 5, "type": "multiple_choice", "question": "Какие из следующих операторов являются логическими в Python?", "options": ["and", "or", "xor", "not"], "correct_answer": ["and", "or", "not"], "explanation": "Логические операторы Python: and, or, not. xor — побитовый (^)."},
        {"id": 6, "type": "single_choice", "question": "Как создать пустой словарь в Python?", "options": ["dict()", "[]", "set()", "()"], "correct_answer": "dict()", "explanation": "dict() или {} создают пустой словарь."},
        {"id": 7, "type": "single_choice", "question": "Что вернёт 10 // 3 в Python?", "options": ["3", "3.33", "4", "3.0"], "correct_answer": "3", "explanation": "Оператор // выполняет целочисленное деление: 10 // 3 = 3."},
        {"id": 8, "type": "multiple_choice", "question": "Какие методы строк возвращают новую строку?", "options": ["upper()", "append()", "replace()", "sort()"], "correct_answer": ["upper()", "replace()"], "explanation": "upper() и replace() возвращают новую строку. append() и sort() — методы списков."},
        {"id": 9, "type": "single_choice", "question": "Какой результат выражения bool('')?", "options": ["True", "False", "None", "Ошибка"], "correct_answer": "False", "explanation": "Пустая строка считается ложным (falsy) значением в Python."},
        {"id": 10, "type": "multiple_choice", "question": "Какие из конструкций используются для обработки исключений?", "options": ["try", "catch", "except", "finally"], "correct_answer": ["try", "except", "finally"], "explanation": "Python использует try/except/finally. catch — из других языков."},
    ],
    "JavaScript": [
        {"id": 1, "type": "single_choice", "question": "Что вернёт typeof null в JavaScript?", "options": ["'null'", "'undefined'", "'object'", "'boolean'"], "correct_answer": "'object'", "explanation": "Это известный баг JS: typeof null === 'object'."},
        {"id": 2, "type": "single_choice", "question": "Какой результат выражения '5' + 3?", "options": ["8", "'53'", "NaN", "Ошибка"], "correct_answer": "'53'", "explanation": "Оператор + со строкой выполняет конкатенацию: '5' + 3 = '53'."},
        {"id": 3, "type": "single_choice", "question": "Как объявить константу в JavaScript?", "options": ["var", "let", "const", "static"], "correct_answer": "const", "explanation": "Ключевое слово const объявляет константу."},
        {"id": 4, "type": "multiple_choice", "question": "Какие значения являются falsy в JavaScript?", "options": ["0", "'false'", "null", "undefined"], "correct_answer": ["0", "null", "undefined"], "explanation": "'false' — непустая строка, она truthy. 0, null, undefined — falsy."},
        {"id": 5, "type": "multiple_choice", "question": "Какие методы массивов НЕ изменяют исходный массив?", "options": ["map()", "push()", "filter()", "splice()"], "correct_answer": ["map()", "filter()"], "explanation": "map() и filter() возвращают новый массив. push() и splice() мутируют исходный."},
        {"id": 6, "type": "single_choice", "question": "Что делает оператор === в JavaScript?", "options": ["Сравнение с приведением типов", "Строгое сравнение", "Присваивание", "Побитовое И"], "correct_answer": "Строгое сравнение", "explanation": "=== сравнивает значение и тип без приведения."},
        {"id": 7, "type": "single_choice", "question": "Какой метод преобразует JSON-строку в объект?", "options": ["JSON.stringify()", "JSON.parse()", "JSON.decode()", "JSON.convert()"], "correct_answer": "JSON.parse()", "explanation": "JSON.parse() разбирает строку JSON и создаёт объект."},
        {"id": 8, "type": "multiple_choice", "question": "Какие способы объявления функций существуют в JS?", "options": ["function declaration", "arrow function", "lambda function", "function expression"], "correct_answer": ["function declaration", "arrow function", "function expression"], "explanation": "В JS нет lambda. Есть function declaration, expression и arrow function."},
        {"id": 9, "type": "single_choice", "question": "Что такое замыкание (closure)?", "options": ["Функция внутри цикла", "Функция, имеющая доступ к переменным внешней функции", "Анонимная функция", "Метод объекта"], "correct_answer": "Функция, имеющая доступ к переменным внешней функции", "explanation": "Замыкание — функция, которая запоминает лексическое окружение места своего создания."},
        {"id": 10, "type": "single_choice", "question": "Что вернёт [1,2,3].length?", "options": ["2", "3", "4", "undefined"], "correct_answer": "3", "explanation": "Свойство length возвращает количество элементов массива."},
    ],
    "Математика": [
        {"id": 1, "type": "single_choice", "question": "Чему равна производная функции f(x) = x²?", "options": ["x", "2x", "x²", "2"], "correct_answer": "2x", "explanation": "По правилу: (xⁿ)' = n·xⁿ⁻¹, значит (x²)' = 2x."},
        {"id": 2, "type": "single_choice", "question": "Сколько будет 7! (факториал)?", "options": ["720", "5040", "40320", "362880"], "correct_answer": "5040", "explanation": "7! = 7×6×5×4×3×2×1 = 5040."},
        {"id": 3, "type": "single_choice", "question": "Чему равен sin(90°)?", "options": ["0", "0.5", "1", "-1"], "correct_answer": "1", "explanation": "Синус прямого угла (90°) равен 1."},
        {"id": 4, "type": "multiple_choice", "question": "Какие из чисел являются простыми?", "options": ["2", "9", "13", "15"], "correct_answer": ["2", "13"], "explanation": "2 и 13 делятся только на 1 и себя. 9=3×3, 15=3×5."},
        {"id": 5, "type": "multiple_choice", "question": "Какие утверждения верны для логарифмов?", "options": ["log(ab) = log(a) + log(b)", "log(a/b) = log(a) - log(b)", "log(a+b) = log(a) · log(b)", "log(aⁿ) = n·log(a)"], "correct_answer": ["log(ab) = log(a) + log(b)", "log(a/b) = log(a) - log(b)", "log(aⁿ) = n·log(a)"], "explanation": "Основные свойства логарифмов. log(a+b) ≠ log(a)·log(b)."},
        {"id": 6, "type": "single_choice", "question": "Решите уравнение: 2x + 5 = 15", "options": ["x = 4", "x = 5", "x = 10", "x = 7.5"], "correct_answer": "x = 5", "explanation": "2x = 15 - 5 = 10, x = 10/2 = 5."},
        {"id": 7, "type": "single_choice", "question": "Площадь круга с радиусом 3 равна:", "options": ["6π", "9π", "3π", "12π"], "correct_answer": "9π", "explanation": "S = πr² = π·3² = 9π."},
        {"id": 8, "type": "single_choice", "question": "Чему равен cos(0°)?", "options": ["0", "0.5", "-1", "1"], "correct_answer": "1", "explanation": "Косинус нулевого угла равен 1."},
        {"id": 9, "type": "multiple_choice", "question": "Какие из фигур являются правильными многоугольниками?", "options": ["Квадрат", "Прямоугольник", "Равносторонний треугольник", "Ромб"], "correct_answer": ["Квадрат", "Равносторонний треугольник"], "explanation": "Правильный многоугольник — все стороны и углы равны. Прямоугольник и ромб не всегда правильные."},
        {"id": 10, "type": "single_choice", "question": "Сумма углов треугольника равна:", "options": ["90°", "180°", "270°", "360°"], "correct_answer": "180°", "explanation": "Сумма внутренних углов любого треугольника равна 180°."},
    ],
}

DEFAULT_QUESTIONS = [
    {"id": 1, "type": "single_choice", "question": "Какой метод научного познания основан на разделении целого на части?", "options": ["Синтез", "Анализ", "Индукция", "Дедукция"], "correct_answer": "Анализ", "explanation": "Анализ — это мысленное разделение объекта на составные части для изучения."},
    {"id": 2, "type": "single_choice", "question": "Что является основой научного метода?", "options": ["Авторитет", "Эксперимент", "Интуиция", "Традиция"], "correct_answer": "Эксперимент", "explanation": "Научный метод основан на наблюдении, гипотезе и экспериментальной проверке."},
    {"id": 3, "type": "single_choice", "question": "Как называется предположение, требующее доказательства?", "options": ["Теория", "Закон", "Гипотеза", "Аксиома"], "correct_answer": "Гипотеза", "explanation": "Гипотеза — научное предположение, которое необходимо проверить."},
    {"id": 4, "type": "multiple_choice", "question": "Какие из перечисленных являются этапами научного исследования?", "options": ["Наблюдение", "Голосование", "Эксперимент", "Анализ данных"], "correct_answer": ["Наблюдение", "Эксперимент", "Анализ данных"], "explanation": "Научное исследование включает наблюдение, эксперимент и анализ."},
    {"id": 5, "type": "multiple_choice", "question": "Какие формы представления информации существуют?", "options": ["Текстовая", "Графическая", "Магическая", "Числовая"], "correct_answer": ["Текстовая", "Графическая", "Числовая"], "explanation": "Информация может быть текстовой, графической, числовой и др."},
    {"id": 6, "type": "single_choice", "question": "Что такое алгоритм?", "options": ["Язык программирования", "Последовательность шагов для решения задачи", "База данных", "Операционная система"], "correct_answer": "Последовательность шагов для решения задачи", "explanation": "Алгоритм — конечная последовательность чётко определённых инструкций."},
    {"id": 7, "type": "single_choice", "question": "Что означает аббревиатура ИИ?", "options": ["Интернет-интерфейс", "Искусственный интеллект", "Информационные инновации", "Интегральный индекс"], "correct_answer": "Искусственный интеллект", "explanation": "ИИ — искусственный интеллект, раздел информатики об имитации интеллектуальных функций."},
    {"id": 8, "type": "multiple_choice", "question": "Какие устройства относятся к устройствам ввода информации?", "options": ["Клавиатура", "Монитор", "Мышь", "Принтер"], "correct_answer": ["Клавиатура", "Мышь"], "explanation": "Клавиатура и мышь — устройства ввода. Монитор и принтер — устройства вывода."},
    {"id": 9, "type": "single_choice", "question": "Что такое база данных?", "options": ["Язык программирования", "Организованный набор структурированных данных", "Антивирусная программа", "Браузер"], "correct_answer": "Организованный набор структурированных данных", "explanation": "База данных — организованная коллекция данных для хранения и управления."},
    {"id": 10, "type": "multiple_choice", "question": "Какие из следующих являются браузерами?", "options": ["Chrome", "Python", "Firefox", "Excel"], "correct_answer": ["Chrome", "Firefox"], "explanation": "Chrome и Firefox — браузеры. Python — язык программирования, Excel — табличный процессор."},
]


def _get_fallback_questions(subject: str) -> list[dict]:
    pool = FALLBACK_QUESTIONS.get(subject, DEFAULT_QUESTIONS)
    selected = random.sample(pool, min(10, len(pool)))
    for i, q in enumerate(selected, 1):
        selected[i - 1] = {**q, "id": i}
    return selected


def _clean_json_response(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        # Remove opening fence (```json or ```)
        text = text.split("\n", 1)[-1]
    if text.endswith("```"):
        text = text.rsplit("```", 1)[0]
    return text.strip()


def generate_test(subject: str, difficulty: str, exclude_questions: list[str] | None = None) -> dict:
    exclude_text = ""
    if exclude_questions:
        exclude_text = "\n\nНе повторяй следующие вопросы:\n" + "\n".join(f"- {q}" for q in exclude_questions)

    user_prompt = f"""Сгенерируй тест по предмету: {subject}
        Уровень сложности: {difficulty}
        {exclude_text}
        
        Формат ответа — JSON:
        {{
          "questions": [
            {{
              "id": 1,
              "type": "single_choice",
              "question": "текст вопроса",
              "options": ["A", "B", "C", "D"],
              "correct_answer": "A",
              "explanation": "объяснение"
            }}
          ]
        }}"""

    try:
        model = genai.GenerativeModel(
            model_name=_gemini_model_name,
            system_instruction=SYSTEM_PROMPT,
        )
        response = model.generate_content(
            user_prompt,
            generation_config=genai.GenerationConfig(
                temperature=0.7,
                response_mime_type="application/json",
            ),
        )
        raw = _clean_json_response(response.text)
        result = json.loads(raw)
        return result
    except Exception as e:
        logger.warning("Gemini API unavailable, using fallback questions: %s", e)
        return {"questions": _get_fallback_questions(subject)}