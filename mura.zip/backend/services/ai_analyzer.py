import json
import os
import logging

import google.generativeai as genai
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger(__name__)


def configure_api(token: str, model_version: str) -> None:
    global _gemini_model_name
    genai.configure(api_key=token)
    _gemini_model_name = model_version

ANALYSIS_PROMPT = """Ты — AI-наставник, который анализирует ошибки студентов в тестах.

Для каждой ошибки предоставь:
1. explanation — почему ответ студента неправильный (2-3 предложения)
2. theory — краткая теория по теме вопроса (3-5 предложений)
3. micro_tasks — 2-3 мини-задания для закрепления материала

Отвечай ТОЛЬКО валидным JSON без markdown-обёртки. Все тексты на русском языке."""


def _clean_json_response(text: str) -> str:
    """Strip possible markdown fences from Gemini response."""
    text = text.strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[-1]
    if text.endswith("```"):
        text = text.rsplit("```", 1)[0]
    return text.strip()


def _fallback_analysis(mistakes_for_ai: list[dict]) -> list[dict]:
    """Generate basic analysis without calling the API."""
    analysis = []
    for m in mistakes_for_ai:
        correct = m["correct_answer"]
        correct_str = ", ".join(correct) if isinstance(correct, list) else str(correct)
        student = m["student_answer"]
        student_str = ", ".join(student) if isinstance(student, list) else str(student)

        analysis.append({
            "question_id": m["question_id"],
            "question": m["question"],
            "student_answer": student_str,
            "correct_answer": correct_str,
            "explanation": f"Вы ответили «{student_str}», но правильный ответ — «{correct_str}». Внимательно перечитайте вопрос и варианты ответа.",
            "theory": m.get("explanation", "Повторите теоретический материал по данной теме для лучшего понимания."),
            "micro_tasks": [
                "Перечитайте определение и приведите свой пример.",
                "Найдите ещё 2 примера по этой теме в учебнике.",
            ],
        })
    return analysis


def analyze_results(questions: list[dict], answers: dict[str, any]) -> dict:
    """Analyze student answers, compute score, generate feedback for mistakes."""
    correct_count = 0
    total = len(questions)
    mistakes = []

    for q in questions:
        q_id = str(q["id"])
        student_answer = answers.get(q_id)
        correct_answer = q["correct_answer"]

        if student_answer is None:
            mistakes.append(q)
            continue

        if isinstance(correct_answer, list):
            is_correct = set(student_answer) == set(correct_answer) if isinstance(student_answer, list) else False
        else:
            is_correct = str(student_answer) == str(correct_answer)

        if is_correct:
            correct_count += 1
        else:
            mistakes.append({**q, "_student_answer": student_answer})

    score = round((correct_count / total) * 100, 1) if total > 0 else 0

    if not mistakes:
        return {
            "score": score,
            "mistakes_analysis": [],
            "homework": [],
        }

    mistakes_for_ai = []
    for m in mistakes:
        mistakes_for_ai.append({
            "question_id": m["id"],
            "question": m["question"],
            "options": m["options"],
            "student_answer": m.get("_student_answer", "нет ответа"),
            "correct_answer": m["correct_answer"],
            "explanation": m.get("explanation", ""),
        })

    try:
        user_prompt = f"""Проанализируй ошибки студента в тесте:
            {json.dumps(mistakes_for_ai, ensure_ascii=False, indent=2)}
            
            Ответь в формате JSON:
            {{
              "analysis": [
                {{
                  "question_id": 1,
                  "question": "текст вопроса",
                  "student_answer": "ответ студента",
                  "correct_answer": "правильный ответ",
                  "explanation": "объяснение ошибки",
                  "theory": "краткая теория",
                  "micro_tasks": ["задание 1", "задание 2"]
                }}
              ]
            }}"""

        model = genai.GenerativeModel(
            model_name=_gemini_model_name,
            system_instruction=ANALYSIS_PROMPT,
        )
        response = model.generate_content(
            user_prompt,
            generation_config=genai.GenerationConfig(
                temperature=0.5,
                response_mime_type="application/json",
            ),
        )
        raw = _clean_json_response(response.text)
        ai_result = json.loads(raw)
        analysis = ai_result.get("analysis", [])
    except Exception as e:
        logger.warning("Gemini API unavailable for analysis, using fallback: %s", e)
        analysis = _fallback_analysis(mistakes_for_ai)

    homework = []
    for item in analysis:
        for task in item.get("micro_tasks", []):
            homework.append({
                "question_id": item["question_id"],
                "task": task,
            })

    return {
        "score": score,
        "mistakes_analysis": analysis,
        "homework": homework,
    }